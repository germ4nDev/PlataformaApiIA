/*
    Author: German Valencia
    Pattern: PORTTOS Service - Motor de Datos Marítimos (PRODUCCIÓN)
    Descripción: Orquestador integral de la Pestaña Marítima (TLC_MARITIMO_001).
*/
const Supertransporte = require('../../adapters/supertransporte.adapter');
const MaritimoRepository = require('../../repositories/torre-control/maritimo.repository');
const ExternalIntegrationService = require('../../adapters/fuentes-externas.adapter');
const MapaPortuarioService = require('../../services/torre-control/mapa-portuario.service');
const { DICCIONARIO_HOMOLOGACION_ETL } = require('../../utils/diccionarios');
const Origen = require('../../utils/origen-dato');
const Lineup = require('../../utils/motonaves-lineup');

// ---------------------------------------------------------------- Line-up vs AIS
const { claveMuelle, mismoBarco, verificarConAis } = require('../../utils/linea-ais');

const AIS_VIGENCIA_MIN = 60; // mismo valor por defecto que los widgets VIVO

class MaritimoService {

  async obtenerOperacionesSLA(puerto) {
    const ciudadKey = puerto ? puerto.toUpperCase() : 'BUENAVENTURA';
    try {
      const kpis = await this._calcularKpisOperativos(2026, 6, ciudadKey);
      return {
        success: true,
        data: {
          KPI_CAMIONES: kpis.KPI_CAMIONES_PUERTO,
          KPI_CONTENEDORES: kpis.KPI_CONTENEDORES,
          KPI_GRANEL: kpis.KPI_GRANEL,
          KPI_CARGA_SUELTA: kpis.KPI_CARGA_SUELTA,
          KPI_RORO: kpis.KPI_RORO,
          KPI_BODEGAS: kpis.KPI_BODEGAS,
          productividad:
            ciudadKey === 'BUENAVENTURA'
              ? {
                SPRBUN: [22, 26, 28, 26, 24, 26, 23, 22],
                SPIA: [38, 42, 45, 43, 40, 44, 41, 39],
                TCBUEN: [42, 48, 52, 49, 47, 50, 46, 44]
              }
              : {
                SPRC: [35, 40, 42, 41, 39, 43, 40, 38],
                CONTECAR: [40, 45, 48, 47, 45, 49, 46, 44]
              }
        }
      };
    } catch (error) {
      throw new Error('Error al procesar el SLA operativo');
    }
  }

  async obtenerLineUp(puerto) {
    const ciudadKey = puerto ? puerto.toUpperCase() : 'BUENAVENTURA';
    try {
      const data = await this._obtenerPronosticoMotonaves(2026, 6, ciudadKey);
      const motonaves =
        data?.WDG_TABLE_REPORTE_MOTONAVES?.motonaves ||
        data?.TABLE_REPORTE_MOTONAVES?.motonaves ||
        [];
      return { success: true, data: motonaves };
    } catch (error) {
      return { success: true, data: [] };
    }
  }

  async _obtenerClima(puerto) {
    try {
      let lat = 3.8801;
      let lon = -77.0319;
      if (puerto === 'CARTAGENA') {
        lat = 10.3910;
        lon = -75.4794;
      } else if (puerto === 'BARRANQUILLA') {
        lat = 10.9685;
        lon = -74.7813;
      } else if (puerto === 'SANTA MARTA') {
        lat = 11.2408;
        lon = -74.2110;
      }

      const [weather, tides] = await Promise.all([
        ExternalIntegrationService.getWeatherData(lat, lon),
        ExternalIntegrationService.getTideData(lat, lon)
      ]);

      // Corregido 2026-10-17: sin respuesta de clima se mostraba "Abierto" en verde como si fuera dato real
      const estadoDelCanal = !weather || !weather.wind
        ? 'Sin datos'
        : (weather.wind.speed > 15 ? 'Restringido' : 'Abierto');
      return {
        success: true,
        data: {
          marea: tides ? tides.nivel : 'N/A',
          pleamar: tides ? tides.hora : 'N/A',
          visibilidad: weather && weather.visibility ? `${(weather.visibility / 1000).toFixed(1)} km` : 'N/A',
          viento: weather && weather.wind ? `${weather.wind.speed} m/s` : 'N/A',
          estadoCanal: estadoDelCanal
        }
      };
    } catch (error) {
      return {
        success: true,
        data: {
          marea: 'N/A',
          pleamar: 'N/A',
          visibilidad: 'N/A',
          viento: 'N/A',
          estadoCanal: 'Desconocido'
        }
      };
    }
  }

  async obtenerResumenOperativo(puerto) {
    const ciudadKey = puerto ? puerto.trim().toUpperCase() : 'BUENAVENTURA';

    // 1. Obtenemos la última fecha registrada en BD con blindaje ante fallos
    let ultimaFecha = await MaritimoRepository.getUltimoPeriodo().catch(() => null);

    // Corregido 2026-10-17: tedious entrega la fecha como Date, y un Date también es 'object';
    // antes se "desempaquetaba" a undefined y siempre se usaba el mes actual en vez del último período RNDC.
    if (ultimaFecha && typeof ultimaFecha === 'object' && !(ultimaFecha instanceof Date)) {
      ultimaFecha =
        ultimaFecha.ultimaFecha ||
        ultimaFecha.fecha ||
        ultimaFecha.max_fecha ||
        ultimaFecha[Object.keys(ultimaFecha)[0]];
    }

    const fecha = new Date(ultimaFecha);
    const periodoValido = ultimaFecha != null && !isNaN(fecha.getTime());
    // SQL Server devuelve el DATETIME como medianoche UTC: se leen año y mes en UTC
    // (en hora Colombia el día 1 a las 00:00 UTC caería en el mes anterior).
    const ahora = new Date();
    const anio = periodoValido ? fecha.getUTCFullYear() : ahora.getFullYear();
    const mes = periodoValido ? fecha.getUTCMonth() + 1 : ahora.getMonth() + 1;

    // OT-009: productividad y reportes guardan el puerto por id del maestro (GUAJIRA) o por nombre (SANTA MARTA)
    const { contextoPuerto } = require('../../helpers/puerto-contexto.helper');
    const ctxPuerto = await contextoPuerto(ciudadKey).catch(() => null);
    const clavesDelPuerto = ctxPuerto ? [ciudadKey, ctxPuerto.idPuerto, ctxPuerto.nombre] : [ciudadKey];

    try {
      const [
        kpisOp,
        terrestres,
        maritimos,
        alertas,
        terminales,
        tablaMotonaves,
        graficaEtaAta,
        graficaToneladas,
        climaRes,
        kpiSemanalReal,
        analisisTraficoNacional,
        participacionNacional,
        mezclaTipoCarga,
        tipoOperacionPortuaria,
        matrizTerminalCarga,
        historicoAnual,
        implicacionesOperativas,
        datosGraficaProductividad,
        reportesCrudos
      ] = await Promise.all([
        this._calcularKpisOperativos(anio, mes, ciudadKey).catch(() => ({})),
        this._calcularKpisTerrestres(anio, mes).catch(() => ({})),
        this._calcularKpisMaritimos(anio, mes, ciudadKey).catch(() => ({})),
        this._calcularKpisAlertas().catch(() => ({})),
        this._obtenerResumenTerminales(anio, mes, ciudadKey).catch(() => ({ WDG_TERMINALES: [] })),
        this._obtenerPronosticoMotonaves(anio, mes, ciudadKey).catch(() => ({
          WDG_TABLE_REPORTE_MOTONAVES: { motonaves: [] }
        })),
        this._obtenerGraficaEtaVsAta(anio, mes, ciudadKey).catch(() => ({
          WDG_CHART_ETA_ATA: { labels: [], datasets: [] }
        })),
        this._obtenerGraficaToneladas(ciudadKey).catch(() => ({
          WDG_CHART_TONELADAS: { labels: [], datasets: [] }
        })),
        this._obtenerClima(ciudadKey).catch(() => ({ data: {} })),
        this._calcularKpiSemanalMaritimo(ciudadKey).catch(() => ({})),
        this._obtenerAnalisisTrafico(ciudadKey).catch(() => this._obtenerMockAnalisisTrafico()),
        this._obtenerParticipacionNacional(ciudadKey).catch(() => ({ labels: [], valores: [] })),
        this._obtenerMezclaCarga(ciudadKey).catch(() => ({ labels: [], valores: [] })),
        this._obtenerTipoOperacion(ciudadKey).catch(() => ({ labels: [], valores: [] })),
        this._obtenerMatrizCarga(ciudadKey).catch(() => ({ filas: [] })),
        this._obtenerHistoricoAnual(ciudadKey).catch(() => ({ labels: [], valores: [] })),
        this._obtenerImplicacionesOperativas(ciudadKey).catch(() => ({ insights: [] })),
        this._obtenerWidgetProductividad(clavesDelPuerto).catch(() => ({
          titulo: 'PRODUCTIVIDAD (MOVS/H)',
          labels: [],
          datasets: []
        })),
        MaritimoRepository.getReportesOperativos(clavesDelPuerto).catch(() => [])
      ]);

      // KPIs de buques desde el estado AIS y los avisos DIMAR (mismo origen que los widgets "en vivo").
      // Agregado 2026-10-17: PTT_MAE_KPI_ESPERADOS / FONDEO / MUELLE no tenían llave y quedaban en 0.
      const kpisAis = await this._calcularKpisBuquesAis(ciudadKey);

      // 1. Mapeo seguro para CONDICIONES_CANAL
      const c = climaRes?.data || {};
      const WDG_CONDICIONES_CANAL = {
        marea: c.marea || 'N/A',
        pleamar: c.pleamar || '--',
        visibilidad: c.visibilidad || 'N/A',
        viento: c.viento || 'N/A',
        estadoCanal: c.estadoCanal || 'Desconocido',
        pilotaje: 'Sin dato',  // no hay fuente de pilotaje (antes 'Normal' fijo)
        claseEstado: c.estadoCanal === 'Abierto' ? 'text-success'
          : (!c.estadoCanal || c.estadoCanal === 'Sin datos' || c.estadoCanal === 'Desconocido') ? 'text-muted' : 'text-danger'
      };

      // 2. Mapeo para ARRIBOS 7 DÍAS (RESUMEN_SEMANAL)
      const listaMotonaves =
        tablaMotonaves?.WDG_TABLE_REPORTE_MOTONAVES?.motonaves ||
        tablaMotonaves?.TABLE_REPORTE_MOTONAVES?.motonaves ||
        [];

      const dataArribosProcesada = this._procesarArribosSemanal(listaMotonaves);

      const WDG_RESUMEN_SEMANAL = {
        titulo: 'ARRIBOS 7 DÍAS',
        labels: dataArribosProcesada.labels,
        datasets: [
          {
            label: 'Arribos',
            data: dataArribosProcesada.data,
            backgroundColor: '#00d4ff',
            borderRadius: 4
          }
        ],
        listado: listaMotonaves,
        arribos: listaMotonaves
      };

      // 3. Mapeo de Reportes Operativos con blindaje anti-nulos
      const WDG_REPORTES_OPERATIVOS = {
        titulo: 'REPORTES OPERATIVOS',
        reportes: (Array.isArray(reportesCrudos) ? reportesCrudos : []).map((rep) => ({
          titulo: rep.titulo,
          descripcion: rep.descripcion,
          fecha_evento: rep.fecha_evento || rep.etiquetaTiempo,
          tipo_color: rep.tipo_color || rep.colorLinea
        }))
      };

      // Origen del dato por nodo (Fase 1, 2026-10-23): de dónde sale y si es valor de respaldo
      const ahora = new Date();
      const conOrigen = (n, datos) => (n && typeof n === 'object' && !Array.isArray(n)
        ? Object.assign(n, { origen: Origen.origen(datos, ahora) }) : n);
      const supertransporte = (n, periodo) => conOrigen(n, {
        fuente: 'Supertransporte (datos.gov.co)', esRespaldo: !!n?.esRespaldo, periodo,
        nota: n?.esRespaldo ? 'La fuente no respondió: se muestran valores de referencia' : null,
      });
      supertransporte(analisisTraficoNacional, 'Últimos 24 meses publicados');
      supertransporte(participacionNacional, 'Último año publicado');
      supertransporte(mezclaTipoCarga, 'Último año publicado');
      supertransporte(tipoOperacionPortuaria, 'Último año publicado');
      supertransporte(matrizTerminalCarga, matrizTerminalCarga?.anio ? `Año ${matrizTerminalCarga.anio}` : 'Último año publicado');
      supertransporte(historicoAnual, historicoAnual?.rango || null);
      supertransporte(implicacionesOperativas, 'Último año publicado');
      conOrigen(kpiSemanalReal, { fuente: 'TCL_LineUpMaritimo', periodo: 'Semana en curso', nota: 'Sin comparativo con la semana anterior' });
      conOrigen(WDG_CONDICIONES_CANAL, { fuente: 'OpenWeather + WorldTides', periodo: 'Consulta en vivo (caché)', nota: 'Pilotaje sin fuente' });
      ['KPI_CONTENEDORES', 'KPI_GRANEL', 'KPI_CARGA_SUELTA', 'KPI_RORO'].forEach((k) => conOrigen(kpisOp[k], {
        fuente: 'TCL_HistoricoProductividad', periodo: 'Promedio diario sobre el histórico cargado',
        nota: 'Sin filtro de fecha: no es el movimiento de hoy',
      }));
      conOrigen(kpisOp.KPI_CAMIONES_PUERTO, { fuente: 'RNDC (TCL_RNDCOperacionTerrestre)', esRespaldo: true, periodo: 'Estimación', nota: 'Estimado con la ley de Little y tiempos de permanencia fijos' });

      const nodoEtaAta = graficaEtaAta?.WDG_CHART_ETA_ATA || { labels: [], datasets: [] };
      const nodoToneladas = graficaToneladas?.WDG_CHART_TONELADAS || { labels: [], datasets: [] };
      const nodoMotonaves = tablaMotonaves?.WDG_TABLE_REPORTE_MOTONAVES || { motonaves: [] };
      const nodoTerminales = terminales?.WDG_TERMINALES || [];

      return {
        ...kpisOp,
        ...terrestres,
        ...maritimos,
        ...alertas,
        ...graficaToneladas,

        // Nodos estándar WDG_*
        WDG_TERMINALES: nodoTerminales,
        WDG_TABLE_REPORTE_MOTONAVES: nodoMotonaves,
        WDG_CHART_ETA_ATA: nodoEtaAta,
        WDG_CONDICIONES_CANAL,
        WDG_CHART_PRODUCTIVIDAD: datosGraficaProductividad,
        WDG_RESUMEN_SEMANAL,
        WDG_PORT_RESUMEN_SEMANAL: WDG_RESUMEN_SEMANAL,
        WDG_REPORTES_OPERATIVOS,
        WDG_SEMANAL_MARITIMO: kpiSemanalReal,
        WDG_ANALISIS_TRAFICO: analisisTraficoNacional,
        WDG_PARTICIPACION_NAC: participacionNacional,
        WDG_MEZCLA_CARGA: mezclaTipoCarga,
        WDG_TIPO_OPERACION: tipoOperacionPortuaria,
        WDG_MATRIZ_TERMINAL_CARGA: matrizTerminalCarga,
        WDG_HISTORICO_ANUAL: historicoAnual,
        WDG_IMPLICACIONES_OPERATIVAS: implicacionesOperativas,

        // Homologación directa con códigos PTT_MAE_* de TLC_MARITIMO_001
        PTT_MAE_CHRT_ETA_ATA: nodoEtaAta,
        PTT_MAE_CHRT_HISTORICO: historicoAnual,
        PTT_MAE_CHRT_HISTORICO_ANUAL: historicoAnual,
        PTT_MAE_CHRT_MEZCLA_CARGA: mezclaTipoCarga,
        PTT_MAE_CHRT_MEZCLA: mezclaTipoCarga,
        PTT_MAE_CHRT_PART_TERM: participacionNacional,
        PTT_MAE_CHRT_PROD: datosGraficaProductividad,
        PTT_MAE_CHRT_TIPO_OP: tipoOperacionPortuaria,
        PTT_MAE_CHRT_TONELADAS: nodoToneladas,
        PTT_MAE_PANEL_TRAFICO: analisisTraficoNacional,
        PTT_MAE_PANEL_CANAL: WDG_CONDICIONES_CANAL,
        PTT_MAE_PANEL_INSIGHTS: implicacionesOperativas,
        PTT_MAE_PANEL_IMPLICACIONES: implicacionesOperativas,
        PTT_MAE_PANEL_REPORTES: WDG_REPORTES_OPERATIVOS,
        PTT_MAE_PANEL_SEMANAL: kpiSemanalReal,
        // Corregido 2026-10-17: PTT_MAE_PANEL_RESUMEN espera metricas[] y recibía la gráfica de arribos
        PTT_MAE_PANEL_RESUMEN: kpiSemanalReal,
        PTT_MAE_PANEL_TERMINALES: nodoTerminales,
        PTT_MAE_TAB_MOTONAVES: nodoMotonaves,
        PTT_MAE_TAB_MATRIZ: matrizTerminalCarga,

        // Homologación de KPIs para códigos PTT_MAE_KPI_*
        PTT_MAE_KPI_CONTENEDORES: kpisOp.KPI_CONTENEDORES,
        PTT_MAE_KPI_GRANEL: kpisOp.KPI_GRANEL,
        PTT_MAE_KPI_CARGA_SUELTA: kpisOp.KPI_CARGA_SUELTA,
        PTT_MAE_KPI_RORO: kpisOp.KPI_RORO,
        PTT_MAE_KPI_BODEGAS: kpisOp.KPI_BODEGAS,
        PTT_MAE_KPI_CAMIONES_PUERTO: kpisOp.KPI_CAMIONES_PUERTO,
        // Corregido 2026-10-17: el widget PTT_MAE_KPI_CAMIONES no tenía llave y siempre mostraba 0
        PTT_MAE_KPI_CAMIONES: kpisOp.KPI_CAMIONES_PUERTO,
        // Estado real desde AIS + avisos DIMAR (maritimo-vivo); sin llave si falta la migración 005
        ...kpisAis,
        PTT_MAE_KPI_CAMIONES_VIA: kpisOp.KPI_CAMIONES_VIA,
        PTT_MAE_KPI_CAMIONES_CARGA: kpisOp.KPI_CAMIONES_CARGA,
        PTT_MAE_KPI_MOTONAVES: maritimos.KPI_MOTONAVES_ACTIVAS,
        PTT_MAE_KPI_VOLUMEN: maritimos.KPI_CARGA_MARITIMA
      };
    } catch (error) {
      console.error('🔥 Error en obtenerResumenOperativo:', error.stack);
      throw new Error('Error al procesar el resumen integral marítimo');
    }
  }

  /**
   * Buques esperados (avisos DIMAR con ETA en 72 h), en fondeo y en muelle (estado AIS vigente).
   * Si falta la migración 005 o el puerto no existe en el maestro, no publica la llave y el widget
   * conserva su comportamiento anterior.
   */
  async _calcularKpisBuquesAis(ciudadKey) {
    const MaritimoVivoService = require('./maritimo-vivo.service');
    const [resumen, llegadas] = await Promise.all([
      MaritimoVivoService.resumen(ciudadKey, { vigenciaMin: 60, limiteCola: 1 }).catch(() => null),
      MaritimoVivoService.llegadas(ciudadKey, { horas: 72, horasAtras: 0, limite: 500 }).catch(() => null)
    ]);
    const kpis = {};
    if (llegadas) {
      const r = llegadas.resumen;
      kpis.PTT_MAE_KPI_ESPERADOS = {
        titulo: 'BUQUES ESPERADOS',
        valor: r.proximas24h + r.de24a48h + r.de48a72h,
        subtitulo: `24h ${r.proximas24h} · 48h ${r.de24a48h} · 72h ${r.de48a72h} · avisos DIMAR`,
        colorBorde: 'borde-cyan'
      };
    }
    if (resumen) {
      const prom = resumen.fondeo.minutosPromedio;
      kpis.PTT_MAE_KPI_FONDEO = {
        titulo: 'BUQUES EN FONDEO',
        valor: resumen.fondeo.naves,
        subtitulo: prom != null ? `Espera promedio ${Math.round((prom / 60) * 10) / 10} h · AIS` : 'En bahía de espera · AIS',
        colorBorde: 'borde-amarillo'
      };
      kpis.PTT_MAE_KPI_MUELLE = {
        titulo: 'BUQUES EN MUELLE',
        valor: resumen.atracadas,
        subtitulo: 'Atracados según AIS (última hora)',
        colorBorde: 'borde-green'
      };
    }
    return kpis;
  }

  async _calcularKpisOperativos(anio, mes, ciudadKey) {
    const dataCamiones = await MaritimoRepository.getKpisOperativos(ciudadKey).catch(() => ({}));

    // 1. Cálculos Base
    const totalViajesPeriodo = parseInt(dataCamiones?.viajes) || 0;
    const lambdaDia = totalViajesPeriodo / 120.0;

    // 2. Tiempos W oficiales
    const w_pre_gate = 0.75;
    const w_puerto = 3.0;
    const w_interior = 4.0;
    const w_corredor = 8.0;
    const w_total = 15.75;

    // 3. Distribución Física
    const totalPreGate = Math.round(lambdaDia * (w_pre_gate / 24.0));
    const totalPuerto = Math.round(lambdaDia * (w_puerto / 24.0));
    const totalInterior = Math.round(lambdaDia * (w_interior / 24.0));
    const totalCorredor = Math.round(lambdaDia * (w_corredor / 24.0));

    const totalUrbano = totalPreGate + totalPuerto + totalInterior;
    const granTotalActivos = totalUrbano + totalCorredor;

    // 4. Distribución por Naturaleza de Carga
    const camionesContenedor = Math.round(lambdaDia * (1487 / 2917) * (w_total / 24.0));
    const camionesGranel = Math.round(lambdaDia * (803 / 2917) * (w_total / 24.0));
    const camionesOtros = granTotalActivos - camionesContenedor - camionesGranel;

    const cargas = await MaritimoRepository.getCargasLineUp(ciudadKey).catch(() => []);
    const listaCargas = Array.isArray(cargas) ? cargas : [];

    const fcl =
      Math.round(
        listaCargas
          .filter((x) => x.tipoCarga?.toUpperCase().includes('FCL'))
          .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) / 30
      ) || 0;
    const lcl =
      Math.round(
        listaCargas
          .filter((x) => x.tipoCarga?.toUpperCase().includes('LCL'))
          .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) / 30
      ) || 0;
    const reefer =
      Math.round(
        listaCargas
          .filter((x) => x.tipoCarga?.toUpperCase().includes('REEFER'))
          .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) / 30
      ) || 0;
    const totalContenedores = fcl + lcl + reefer;

    const agricola =
      listaCargas
        .filter((x) => x.tipoCarga?.toUpperCase().includes('AGRICOLA'))
        .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) || 0;
    const mineral =
      listaCargas
        .filter((x) => x.tipoCarga?.toUpperCase().includes('MINERAL'))
        .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) || 0;
    const liquido =
      listaCargas
        .filter((x) => x.tipoCarga?.toUpperCase().includes('LIQUIDO'))
        .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) || 0;
    const totalGranel = agricola + mineral + liquido;

    const breakBulk =
      Math.round(
        listaCargas
          .filter((x) => x.operacionActual?.toUpperCase().includes('BREAK'))
          .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) / 30
      ) || 0;
    const project =
      Math.round(
        listaCargas
          .filter((x) => x.operacionActual?.toUpperCase().includes('PROJECT'))
          .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) / 30
      ) || 0;
    const paletizada =
      Math.round(
        listaCargas
          .filter((x) => x.operacionActual?.toUpperCase().includes('PALET'))
          .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) / 30
      ) || 0;
    const totalSuelta = breakBulk + project + paletizada;

    const impVehiculos =
      Math.round(
        listaCargas
          .filter(
            (x) =>
              x.tipoCarga?.toUpperCase().includes('VEHICULO') &&
              x.operacionActual?.toUpperCase().includes('IMPORT')
          )
          .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) / 30
      ) || 0;
    const expVehiculos =
      Math.round(
        listaCargas
          .filter(
            (x) =>
              x.tipoCarga?.toUpperCase().includes('VEHICULO') &&
              x.operacionActual?.toUpperCase().includes('EXPORT')
          )
          .reduce((a, b) => a + (parseFloat(b.volumenTotal) || 0), 0) / 30
      ) || 0;
    const totalVehiculos = impVehiculos + expVehiculos;

    return {
      KPI_CAMIONES_PUERTO: {
        valor: totalUrbano.toLocaleString('es-CO'),
        subtitulo: `hoy · pre-gate ${totalPreGate} · interior ${totalInterior} · puerto ${totalPuerto}`,
        tendencia: `ZONA URBANA ${ciudadKey}`,
        titulo: 'CAMIONES EN PUERTO',
        colorBorde: 'borde-cyan'
      },
      KPI_CAMIONES_VIA: {
        valor: totalCorredor.toLocaleString('es-CO'),
        subtitulo: `Tránsito ruta ${ciudadKey} - Corredor Logístico`,
        tendencia: 'CORREDOR LOGÍSTICO VÍA AL MAR',
        titulo: 'CAMIONES EN TRÁNSITO',
        colorBorde: 'borde-amarillo'
      },
      KPI_CAMIONES_CARGA: {
        valor: granTotalActivos.toLocaleString('es-CO'),
        subtitulo: `Contenedor ${camionesContenedor} · Granel ${camionesGranel} · General/Otros ${camionesOtros}`,
        tendencia: `INVENTARIO TOTAL DEL SISTEMA (${w_total}h)`,
        titulo: 'CAMIONES POR TIPO CARGA',
        colorBorde: 'borde-naranja'
      },
      KPI_CONTENEDORES: {
        valor: totalContenedores.toLocaleString('es-CO'),
        subtitulo: `FCL ${fcl.toLocaleString('es-CO')} · LCL ${lcl.toLocaleString('es-CO')} · Reefer ${reefer.toLocaleString('es-CO')}`,
        tendencia: `FCL ${fcl.toLocaleString('es-CO')} · LCL ${lcl.toLocaleString('es-CO')} · Reefer ${reefer.toLocaleString('es-CO')}`,
        titulo: 'CONTENEDORES DÍA',
        colorBorde: 'borde-cyan'
      },
      KPI_GRANEL: {
        valor: this._formatearNumeroCompacto(totalGranel / 30),
        subtitulo: `Agrícola ${this._formatearNumeroCompacto(agricola)} · Mineral ${this._formatearNumeroCompacto(mineral)} · Líquido ${this._formatearNumeroCompacto(liquido)}`,
        tendencia: `Agrícola ${this._formatearNumeroCompacto(agricola)} · Mineral ${this._formatearNumeroCompacto(mineral)} · Líquido ${this._formatearNumeroCompacto(liquido)}`,
        titulo: 'GRANEL - TONS DÍA',
        colorBorde: 'borde-naranja'
      },
      KPI_CARGA_SUELTA: {
        valor: totalSuelta.toLocaleString('es-CO'),
        subtitulo: `Break-bulk ${breakBulk} · Project ${project} · Paletizada ${paletizada}`,
        tendencia: `Break-bulk ${breakBulk} · Project ${project} · Paletizada ${paletizada}`,
        titulo: 'CARGA SUELTA - TM',
        colorBorde: 'borde-amarillo'
      },
      KPI_RORO: {
        valor: totalVehiculos.toLocaleString('es-CO'),
        subtitulo: `Imp ${impVehiculos} · Exp ${expVehiculos}`,
        tendencia: `Imp ${impVehiculos} · Exp ${expVehiculos}`,
        titulo: 'VEHÍCULOS RO-RO',
        colorBorde: 'borde-teal'
      },
      KPI_BODEGAS: await this._kpiBodegas(ciudadKey)
    };
  }

  /**
   * Saturación de bodegas del puerto desde TCL_MaestroBodegas (corregido 2026-10-23: antes '72%' / '85%' y
   * "8 bodegas · 2 críticas" escritos a mano según el puerto).
   */
  async _kpiBodegas(ciudadKey) {
    let bodegas = [];
    try {
      // require diferido: el repositorio carga su modelo Sequelize y aquí solo se usa para este KPI
      const bodegasRepository = require('../../repositories/torre-control/bodegas.repository');
      // OT-009: también el id del maestro (el selector manda LA_GUAJIRA; las bodegas guardan GUAJIRA)
      const { contextoPuerto } = require('../../helpers/puerto-contexto.helper');
      const clave = String(ciudadKey || '').toUpperCase();
      const ctx = await contextoPuerto(clave).catch(() => null);
      bodegas = await bodegasRepository.obtenerMaestroBodegasPorPuerto(ctx ? [clave, ctx.idPuerto] : clave);
    } catch (error) {
      console.warn('⚠️ [Marítimo] KPI de bodegas sin datos:', error.message);
    }
    const conCap = bodegas.filter((b) => Number(b.capacidad_maxima_ton) > 0);
    const cap = conCap.reduce((a, b) => a + Number(b.capacidad_maxima_ton), 0);
    const inv = conCap.reduce((a, b) => a + Number(b.inventario_actual_ton || 0), 0);
    const pct = cap > 0 ? Math.round((inv / cap) * 100) : null;
    const criticas = bodegas.filter((b) => Number(b.ocupacion_pct) >= 90).length;
    const texto = bodegas.length ? `${bodegas.length} bodegas · ${criticas} críticas` : 'Sin bodegas registradas';
    return {
      valor: pct === null ? '—' : `${pct}%`, subtitulo: texto, tendencia: texto, titulo: 'SATURACIÓN BODEGAS', colorBorde: 'borde-fucsia',
      origen: Origen.origen({ fuente: 'TCL_MaestroBodegas', periodo: 'Inventario actual' }),
    };
  }

  async _obtenerPronosticoMotonaves(anio, mes, ciudadKey) {
    const todas = await MaritimoRepository.getPronosticoMotonaves(ciudadKey).catch(() => []);
    // Corregido 2026-10-25: ventana real de 72 h (antes todo el line-up activo)
    const ahora = new Date();
    const ventana = Lineup.enVentana(Array.isArray(todas) ? todas : [], ahora, 72);
    const data = ventana.filas;

    if (!Array.isArray(data) || data.length === 0) {
      console.warn(`[WARN] No se encontraron motonaves para: ${ciudadKey}`);
      return { WDG_TABLE_REPORTE_MOTONAVES: { motonaves: [] } };
    }

    const formatearFecha = (fechaStr) => {
      if (!fechaStr) return '--';
      const d = new Date(fechaStr);
      if (isNaN(d.getTime())) return '--';
      return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    };

    const navierasMock = ['MSC', 'Maersk', 'Hapag-Lloyd', 'CMA CGM', 'Evergreen', 'Hamburg Süd'];

    const motonavesFormateadas = data.map((b, index) => {
      const estadoStr = (b.estadoOperacion || 'EN TRÁNSITO').toUpperCase();

      let clasePildora = 'badge-transito';
      let textoEstado = 'EN TRÁNSITO';

      if (
        estadoStr.includes('DESCARGA') ||
        estadoStr.includes('DISCHARGE') ||
        estadoStr.includes('ATRACADO')
      ) {
        clasePildora = 'badge-descargando';
        textoEstado = 'DESCARGANDO';
      } else if (
        estadoStr.includes('FONDEO') ||
        estadoStr.includes('ESPERA') ||
        estadoStr.includes('ANCHOR')
      ) {
        clasePildora = 'badge-fondeo';
        textoEstado = 'EN FONDEO';
      }

      const cantidadReal = parseFloat(b.cantidadMovida) || 0;
      const tipoCargaReal = (b.tipoCarga || 'GENERAL').toUpperCase();

      let textoCarga = `${cantidadReal.toLocaleString('es-CO')} TM`;
      let tipoBuque = 'Multipropósito';

      if (tipoCargaReal.includes('CONTENEDOR') || tipoCargaReal.includes('FCL')) {
        textoCarga = `${cantidadReal.toLocaleString('es-CO')} TEU`;
        tipoBuque = 'Portacont.';
      } else if (tipoCargaReal.includes('AGRICOLA') || tipoCargaReal.includes('MINERAL')) {
        textoCarga = `${cantidadReal.toLocaleString('es-CO')} TM`;
        tipoBuque = 'Granelero';
      }

      return {
        motonave: b.nombreMotonave || 'DESCONOCIDO',
        // Corregido 2026-10-17: la consulta ya trae la agencia naviera; antes se rotaba una lista fija
        naviera: b.agenciaNaviera || b.agencia || 'ND',
        terminal: b.terminal || 'ND',
        tipo: tipoBuque,
        carga: textoCarga,
        eta: formatearFecha(b.fechaETA),
        ata: b.fechaATA ? formatearFecha(b.fechaATA) : '--',
        estadoTexto: textoEstado,
        estadoClase: clasePildora,
        // Vista ampliada (Fase 3): columnas del line-up que antes se descartaban
        muelle: b.muelleAsignado || null,
        estadoReal: b.estadoReal || null,
        lineaAgencia: b.lineaAgencia || null,
        viaje: b.viaje || null,
        eslora: Number(b.eslora) || null,
        zarpe: b.fechaZarpe ? formatearFecha(b.fechaZarpe) : null,
        novedades: b.novedades || null,
        etaIso: Lineup.fecha(b.fechaETA) !== null ? new Date(Lineup.fecha(b.fechaETA)).toISOString() : null,
        atrasada: !b.fechaATA && Lineup.fecha(b.fechaETA) !== null && Lineup.fecha(b.fechaETA) < ahora.getTime()
      };
    });

    return {
      WDG_TABLE_REPORTE_MOTONAVES: {
        motonaves: motonavesFormateadas,
        origen: Origen.origen({
          fuente: 'TCL_LineUpMaritimo + agencias DIMAR', periodo: 'Próximas 72 h y atracadas (zarpe en las últimas 24 h)',
          nota: [ventana.fuera ? `${ventana.fuera} motonaves fuera de la ventana` : null, ventana.sinFecha ? `${ventana.sinFecha} sin fecha legible` : null],
        }, ahora),
      },
    };
  }

  async _calcularKpisTerrestres(anio, mes) {
    const r = await MaritimoRepository.getKpisTerrestres(anio, mes).catch(() => [
      { v: 0, c: 0, f: 0, g: 0 }
    ]);
    const data = r[0] || {};
    return {
      KPI_VIAJES: {
        titulo: 'VIAJES RNDC',
        valor: this._formatearNumeroCompacto(data.v),
        colorBorde: 'borde-cyan'
      },
      KPI_CARGA_TOTAL: {
        titulo: 'CARGA KG',
        valor: this._formatearNumeroCompacto(data.c),
        colorBorde: 'borde-verde'
      },
      KPI_ECONOMICO: {
        titulo: 'COSTO FLETES',
        valor: `$${this._formatearNumeroCompacto(data.f)}`,
        colorBorde: 'borde-purpura'
      },
      KPI_AMBIENTAL: {
        titulo: 'COMBUSTIBLE',
        valor: `${this._formatearNumeroCompacto(data.g)} Gal`,
        colorBorde: 'borde-esmeralda'
      }
    };
  }

  async _calcularKpisMaritimos(anio, mes, ciudadKey) {
    const r = await MaritimoRepository.getKpisMaritimos(ciudadKey).catch(() => [{ n: 0, c: 0 }]);
    return {
      KPI_MOTONAVES_ACTIVAS: {
        titulo: 'MOTONAVES',
        valor: (r[0]?.n || 0).toString(),
        colorBorde: 'borde-azul'
      },
      KPI_CARGA_MARITIMA: {
        titulo: 'VOLUMEN MARÍTIMO',
        valor: this._formatearNumeroCompacto(r[0]?.c),
        colorBorde: 'borde-verde'
      }
    };
  }

  async _calcularKpisAlertas() {
    const r = await MaritimoRepository.getAlertasViales().catch(() => [{ a: 0 }]);
    return {
      KPI_ALERTAS_VIALES: {
        titulo: 'EVENTOS VIALES',
        valor: (r[0]?.a || 0).toString(),
        colorBorde: 'borde-verde'
      }
    };
  }

  async _obtenerResumenTerminales(anio, mes, ciudadKey) {
    const mapaCompletoBD = await MapaPortuarioService.obtenerMapaFormatoFrontend().catch(() => ({}));
    const llavesDisponibles = Object.keys(mapaCompletoBD || {});
    const llaveReal = llavesDisponibles.find(
      (k) => k.toUpperCase().includes(ciudadKey) || ciudadKey.includes(k.toUpperCase())
    );
    const config = mapaCompletoBD[ciudadKey] || (llaveReal ? mapaCompletoBD[llaveReal] : null);

    if (!config || !config.infraestructura) {
      console.warn(`[WARN] No hay terminales configuradas en la BD para: ${ciudadKey}`);
      return { WDG_TERMINALES: [] };
    }

    const [data, aisPorMuelle] = await Promise.all([
      MaritimoRepository.getTerminalesLineUp(ciudadKey).catch(() => []),
      this._ocupacionAisPorMuelle(ciudadKey)
    ]);
    const listaLineUp = Array.isArray(data) ? data : [];

    const terminalesDTO = Object.keys(config.infraestructura).map((id) => {
      const term = config.infraestructura[id];
      const configId = id.trim().toUpperCase();

      const registrosTerminal = listaLineUp.filter((op) => {
        const dbNameRaw = (op.codigoTerminal || op.terminal || '').trim().toLowerCase();
        const codigoOficial = DICCIONARIO_HOMOLOGACION_ETL[dbNameRaw] || dbNameRaw.toUpperCase();
        return codigoOficial === configId || dbNameRaw.toUpperCase().includes(configId);
      });

      const muellesConfig = Array.isArray(term.muelles) ? term.muelles : [];

      const tablaMuelles = muellesConfig.map((m) => {
        const idVisual = (m.id || '').trim().toUpperCase();
        const idBaseDatos = (m.dbId || '').trim().toUpperCase();

        // El line-up ya viene filtrado a "atracado y sin zarpe" y ordenado del atraque más reciente.
        const barcoDB = registrosTerminal.find((o) => {
          const dbMuelle = (o.muelle || '').trim().toUpperCase();
          if (!dbMuelle) return false;
          return dbMuelle === idVisual || dbMuelle === idBaseDatos;
        });
        const barcoLineUp = barcoDB ? barcoDB.barco || barcoDB.motonave || 'SIN NOMBRE' : null;

        const navesAis = aisPorMuelle ? aisPorMuelle.get(claveMuelle(id, m.id)) || [] : null;
        const ais = verificarConAis(barcoLineUp, navesAis);
        const enMantenimiento = Boolean(m.estadoMantenimiento);

        // Ocupado si lo dice el line-up o si el AIS ve un barco atracado que el line-up no reporta.
        const nombreBarco = barcoLineUp || (ais.estado === 'NO_REPORTADO' ? ais.naves[0].nombre || `MMSI ${ais.naves[0].mmsi}` : null);
        const ocupado = Boolean(nombreBarco);

        let operacionTexto = 'DISPONIBLE';
        let clasePildora = 'badge-libre';
        if (barcoDB) {
          const pos = (barcoDB.estado_posicion || barcoDB.posicion || '').toUpperCase();
          const trabajo = (barcoDB.tipo_trabajo || barcoDB.trabajoOperacion || '').toUpperCase();
          if (trabajo.includes('DESCARGA') || trabajo.includes('CARGA')) {
            clasePildora = 'badge-descargando';
            operacionTexto = trabajo;
          } else {
            clasePildora = 'badge-atracando';
            operacionTexto = pos || 'ATRACADO';
          }
        } else if (ocupado) {
          clasePildora = 'badge-atracando';
          operacionTexto = 'ATRACADO (AIS)';
        } else if (enMantenimiento) {
          clasePildora = 'badge-mantenimiento';
          operacionTexto = 'MANTENIMIENTO';
        }

        const status = ocupado ? 'occupied' : enMantenimiento ? 'maintenance' : 'free';

        return {
          id: m.id,
          especialidad: m.esp,
          draft: m.calado,
          calado: m.calado,
          vessel: nombreBarco || '—',
          barco: nombreBarco || '—',
          motonave: nombreBarco || '—',
          barcoAtracado: nombreBarco,
          operacionBarco: operacionTexto,
          operation: operacionTexto,
          operacion: operacionTexto,
          claseEstado: clasePildora,
          status,
          estado: ocupado ? 'ocupado' : enMantenimiento ? 'mantenimiento' : 'libre',
          enMantenimiento,
          fechaAtraque: barcoDB ? barcoDB.fechaAtraque || null : null,
          ais,
          cantidad: barcoDB ? parseFloat(barcoDB.cantidadMovida) || 0 : 0
        };
      });

      const muellesOcupados = tablaMuelles.filter((m) => m.status === 'occupied');
      const totalOcupados = muellesOcupados.length;
      const totalToneladas = tablaMuelles.reduce((acc, curr) => acc + curr.cantidad, 0);
      // Igual que el widget VIVO: los muelles en mantenimiento no cuentan como capacidad.
      const operables = tablaMuelles.filter((m) => !m.enMantenimiento || m.status === 'occupied').length;
      const porcentajeOcupacion = operables > 0 ? Math.round((totalOcupados / operables) * 100) : 0;
      const cuentaAis = (estado) => tablaMuelles.filter((m) => m.ais.estado === estado).length;

      return {
        id: `WDG_RESUMEN_${id}`,
        title: term.nombre,
        nombreTerminal: term.nombre,
        subtitle: term.sub,
        status: 'operative',
        badgeCount: `${totalOcupados}/${muellesConfig.length}`,
        legend: term.desc,
        docks: tablaMuelles.map((m) => ({
          label: m.id,
          class: m.status,
          barcoAtracado: m.barcoAtracado,
          operation: m.operacion,
          especialidad: m.especialidad,
          ais: m.ais
        })),
        kpis: {
          occupancy: `${porcentajeOcupacion}%`,
          ocupacion: `${porcentajeOcupacion}%`,
          vessels: totalOcupados,
          motonaves: totalOcupados,
          metricValue: this._formatearNumeroCompacto(totalToneladas),
          metricLabel: term.unidad,
          confirmadosAis: cuentaAis('CONFIRMADO'),
          sinConfirmarAis: cuentaAis('SIN_CONFIRMAR'),
          discrepanciasAis: cuentaAis('DISCREPANCIA') + cuentaAis('NO_REPORTADO')
        },
        aisDisponible: Boolean(aisPorMuelle),
        tableData: tablaMuelles
      };
    });

    return { WDG_TERMINALES: terminalesDTO };
  }

  /** Naves atracadas según AIS, por muelle (clave terminal|muelle). null si no hay datos AIS para el puerto. */
  async _ocupacionAisPorMuelle(ciudadKey) {
    try {
      const MaritimoVivoService = require('./maritimo-vivo.service');
      const ocupacion = await MaritimoVivoService.ocupacion(ciudadKey, { vigenciaMin: AIS_VIGENCIA_MIN });
      const porMuelle = new Map();
      for (const t of ocupacion.terminales || []) {
        for (const muelle of t.muelles || []) porMuelle.set(claveMuelle(t.idTerminal, muelle.codigoMuelle), muelle.naves || []);
      }
      return porMuelle;
    } catch (error) {
      console.warn(`[WARN] Sin confirmación AIS para ${ciudadKey}: ${error.message}`);
      return null;
    }
  }

  async _obtenerGraficaEtaVsAta(anio, mes, ciudadKey) {
    try {
      const mapaCompletoBD = await MapaPortuarioService.obtenerMapaFormatoFrontend().catch(() => ({}));
      const llavesDisponibles = Object.keys(mapaCompletoBD || {});
      // OT-009: las llaves son nombres ('COVEÑAS', 'SANTA MARTA', 'LA GUAJIRA'); se comparan sin tildes y con '_' por espacio
      const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toUpperCase().trim().replace(/\s+/g, '_');
      const clave = norm(ciudadKey);
      const llaveReal = llavesDisponibles.find((k) => norm(k).includes(clave) || clave.includes(norm(k)));
      const config = llaveReal ? mapaCompletoBD[llaveReal] : null;

      if (!config || !config.infraestructura) {
        return { WDG_CHART_ETA_ATA: { labels: [], datasets: [] } };
      }

      const data = await MaritimoRepository.getGraficaEtaAta(ciudadKey).catch(() => []);
      const listaEtaAta = Array.isArray(data) ? data : [];

      const idsTerminales = Object.keys(config.infraestructura);
      const labelsLimpios = [];
      const datosRetraso = [];
      const datosPlaneado = [];

      idsTerminales.forEach((id) => {
        const terminalConfig = config.infraestructura[id];
        const configId = id.trim().toUpperCase();
        const nombreMostrar = terminalConfig.nombre;

        const row = listaEtaAta.find((r) => {
          const dbNameRaw = (r.terminal || '').trim().toLowerCase();
          const codigoOficial = DICCIONARIO_HOMOLOGACION_ETL[dbNameRaw] || dbNameRaw.toUpperCase();
          return codigoOficial === configId || dbNameRaw.toUpperCase().includes(configId);
        });

        if (row) {
          const retrasoH = Math.round(parseFloat(row.retrasoPromedio || 0));
          labelsLimpios.push(nombreMostrar);
          datosRetraso.push(retrasoH);
          datosPlaneado.push(0);
        }
      });

      return {
        WDG_CHART_ETA_ATA: {
          titulo: '⏱️ REPORTE ETA VS ATA',
          subtitulo: `Comparativa promedio (h) - ${ciudadKey}`,
          labels: labelsLimpios,
          datasets: [
            { label: 'Retraso real (h)', data: datosRetraso, backgroundColor: '#ff526a' }
          ]
        }
      };
    } catch (error) {
      console.error('🔥 Error en _obtenerGraficaEtaVsAta:', error);
      return { WDG_CHART_ETA_ATA: { labels: [], datasets: [] } };
    }
  }

  /**
   * Toneladas movidas hoy por terminal y tipo (OT-009, 2026-10-29): avance de hoy de las operaciones de granel y Ro-Ro del
   * puerto (utils/toneladas-hoy.js). Antes: cinco terminales quemadas de un solo puerto y una tabla vacía → ceros en todos.
   */
  async _obtenerGraficaToneladas(ciudadKey, ahora = new Date()) {
    const OperacionRepository = require('../../repositories/torre-control/operacion-portuaria.repository');
    const { contextoPuerto } = require('../../helpers/puerto-contexto.helper');
    const { armarToneladasHoy } = require('../../utils/toneladas-hoy');
    const ctx = await contextoPuerto(ciudadKey);
    const desde = new Date(ahora.getTime() - 26 * 3600000).toISOString();
    const leer = (promesa) => promesa.catch((e) => (e?.codigo === 'MIGRACION_PENDIENTE' ? [] : Promise.reject(e)));
    const [opsG, opsR, avG, avR] = await Promise.all([
      leer(OperacionRepository.operaciones(ctx.idPuerto, 'GRANEL', desde)), leer(OperacionRepository.operaciones(ctx.idPuerto, 'RORO', desde)),
      leer(OperacionRepository.avance(ctx.idPuerto, 'GRANEL', desde)), leer(OperacionRepository.avance(ctx.idPuerto, 'RORO', desde)),
    ]);
    return { WDG_CHART_TONELADAS: armarToneladasHoy({ operaciones: [...opsG, ...opsR], avance: [...avG, ...avR] }, ahora) };
  }

  async _calcularKpiSemanalMaritimo(ciudadKey) {
    const r = await MaritimoRepository.getResumenSemanalMaritimo(ciudadKey).catch((err) => {
      console.error('🔥 Error SQL en getResumenSemanalMaritimo:', err.message);
      return [{ totalMotonaves: 0, totalTeus: 0, totalGranel: 0, totalVehiculos: 0 }];
    });

    const data = r[0] || {};

    let motonaves = parseInt(data.totalMotonaves) || 0;
    let teus = parseFloat(data.totalTeus) || 0;
    let granel = parseFloat(data.totalGranel) || 0;
    let vehiculos = parseFloat(data.totalVehiculos) || 0;

    // Corregido 2026-10-23: sin datos de la semana ya no se muestran cifras de referencia (86 / 142.000...) y las
    // tendencias ('▲ 4 vs sem. anterior', '+8.2% YoY'...) no se escriben a mano: no hay serie para compararlas.
    const sinDatos = motonaves === 0 && teus === 0 && granel === 0 && vehiculos === 0;
    const tend = () => ({ tendencia: sinDatos ? 'Sin datos de la semana' : 'Sin comparativo', claseTendencia: 'text-muted' });

    return {
      titulo: 'RESUMEN SEMANAL MARÍTIMO',
      metricas: [
        {
          label: 'MOTONAVES ATENDIDAS',
          valor: motonaves.toString(),
          ...tend()
        },
        {
          label: 'TEUS TOTALES',
          valor: this._formatearNumeroCompacto(teus),
          ...tend()
        },
        {
          label: 'TM GRANEL',
          valor: this._formatearNumeroCompacto(granel),
          ...tend()
        },
        {
          label: 'VEHÍCULOS',
          valor: vehiculos.toLocaleString('es-CO'),
          ...tend()
        }
      ]
    };
  }

  /**
   * Zona de Supertransporte del puerto (TCL_MaestroPuertos.zona_supertransporte, migración 024; OT-009): Coveñas es
   * 'G. MORROSQUILLO', La Guajira 'GUAJIRA' y Puerto Antioquia 'TURBO'. Sin la 024 o sin puerto, la clave como antes.
   */
  async _zonaSupertransporte(ciudadKey) {
    const clave = (ciudadKey || 'BUENAVENTURA').toUpperCase().trim();
    try {
      const { contextoPuerto } = require('../../helpers/puerto-contexto.helper');
      const HistoricosRepository = require('../../repositories/torre-control/historicos-supertransporte.repository');
      const ctx = await contextoPuerto(clave);
      const p = (await HistoricosRepository.zonasPuertos()).find((x) => x.idPuerto === ctx.idPuerto);
      return p?.zona || clave;
    } catch {
      return clave;
    }
  }

  async _obtenerAnalisisTrafico(ciudadKey) {
    try {
      let anioActual = new Date().getFullYear();

      const respuesta = { data: await Supertransporte.traficoDesdeAnio(await this._zonaSupertransporte(ciudadKey), anioActual - 2, 50000) };

      const datos = respuesta.data;
      if (!datos || datos.length === 0) throw new Error('API vacía');

      // Corregido 2026-10-17: Supertransporte publica con rezago; con el año calendario el panel mostraba
      // "0.0 M t" y "-100 %". Se compara el último año publicado contra el anterior.
      const aniosConDatos = datos.map((row) => parseInt(row.a_o_vigencia || row.ano_vigencia)).filter(Boolean);
      if (aniosConDatos.length) anioActual = Math.max(...aniosConDatos);

      let totalAnioActual = 0;
      let totalAnioAnterior = 0;
      let totalImpo = 0;
      let granTotal = 0;
      const agrupacionMensual = {};

      datos.forEach((row) => {
        const anio = parseInt(row.a_o_vigencia || row.ano_vigencia);
        const mes = parseInt(row.mes_vigencia);
        if (!anio || !mes) return;

        const expo = parseFloat(row.exportacion) || 0;
        const impo = parseFloat(row.importaci_n || row.importacion) || 0;
        const cabotaje = parseFloat(row.cabotaje) || 0;
        const transbordo = parseFloat(row.transbordo) || 0;
        const fluvial = parseFloat(row.fluvial) || 0;

        const totalFila = expo + impo + cabotaje + transbordo + fluvial;

        if (anio === anioActual) totalAnioActual += totalFila;
        if (anio === anioActual - 1) totalAnioAnterior += totalFila;
        totalImpo += impo;
        granTotal += totalFila;

        const llaveMes = `${anio}-${String(mes).padStart(2, '0')}`;
        if (!agrupacionMensual[llaveMes]) agrupacionMensual[llaveMes] = {};

        const tipoCargaStr = (row.tipo_de_carga || 'OTRO').toUpperCase();
        let categoria = 'General / vehíc.';

        if (tipoCargaStr.includes('CONTENEDOR')) categoria = 'Contenedores';
        else if (tipoCargaStr.includes('LIQUIDO')) categoria = 'Granel líquido';
        else if (tipoCargaStr.includes('CARBON') || tipoCargaStr.includes('CARBÓN')) categoria = 'Carbón';
        else if (tipoCargaStr.includes('GRANEL')) categoria = 'Granel sólido';

        agrupacionMensual[llaveMes][categoria] =
          (agrupacionMensual[llaveMes][categoria] || 0) + totalFila;
      });

      const labels = Object.keys(agrupacionMensual).sort();
      const mesesNombres = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
      const labelsFormat = labels.map((l) => {
        const [a, m] = l.split('-');
        return `${mesesNombres[parseInt(m) - 1]} ${a.slice(-2)}`;
      });

      const categorias = ['Contenedores', 'Granel sólido', 'General / vehíc.', 'Granel líquido', 'Carbón'];
      const colores = ['#00d4ff', '#10b981', '#f59e0b', '#8b5cf6', '#64748b'];

      const datasets = categorias.map((cat, idx) => ({
        label: cat,
        backgroundColor: colores[idx],
        data: labels.map((l) => agrupacionMensual[l][cat] || 0)
      }));

      const variacion =
        totalAnioAnterior > 0
          ? ((totalAnioActual - totalAnioAnterior) / totalAnioAnterior) * 100
          : 0;
      const pctImpo = granTotal > 0 ? (totalImpo / granTotal) * 100 : 0;
      const valorVariacion = (variacion > 0 ? '+' : '') + variacion.toFixed(1) + '%';

      return {
        titulo: `ANÁLISIS DE TRÁFICO PORTUARIO - ${ciudadKey}`,
        subtitulo:
          'Fuente: Supertransporte (API Socrata) · toneladas movilizadas por tipo de carga y operación',
        kpisTop: {
          toneladas: {
            valor: `${(totalAnioActual / 1000000).toFixed(1)} M t`,
            detalle: `${totalAnioActual.toLocaleString('es-CO')} t · acumulado ${anioActual}`
          },
          variacion: {
            valor: valorVariacion,
            detalle: `${anioActual - 1} → ${anioActual} · comparativo YoY`,
            claseTendencia: variacion >= 0 ? 'text-success' : 'text-danger'
          },
          // Corregido 2026-10-23: antes '13.2% · #4 puerto · líder del Pacífico' fijo para todos los puertos
          participacion: {
            valor: '—',
            detalle: 'Participación nacional sin calcular (pendiente de fuente)'
          },
          flujo: {
            valor: `IMPO ${pctImpo.toFixed(0)}%`,
            detalle: `${(totalImpo / 1000000).toFixed(1)} M t importadas · puerto fundamentalmente importador`,
            claseTendencia: 'text-info'
          }
        },
        chartEvolucion: { labels: labelsFormat, datasets }
      };
    } catch (error) {
      console.warn('⚠️ API Supertransporte falló. Entrando en modo Fallback local...', error.message);
      return this._obtenerMockAnalisisTrafico();
    }
  }

  async _obtenerParticipacionNacional(ciudadKey) {
    try {
      const zonaFiltro = await this._zonaSupertransporte(ciudadKey);

      const respuesta = { data: await Supertransporte.traficoPorZona(zonaFiltro, 4000) };
      let datos = respuesta.data;
      if (!datos || datos.length === 0) throw new Error('Sin datos de terminales');

      const anioReportado =
        Math.max(...datos.map((d) => parseInt(d.a_o_vigencia || d.vigencia || 0)).filter((a) => a > 0)) ||
        new Date().getFullYear();
      datos = datos.filter((d) => parseInt(d.a_o_vigencia || d.vigencia) === anioReportado);

      const toneladasPorTerminal = {};
      let granTotal = 0;

      datos.forEach((row) => {
        let terminal = (row.sociedad_portuaria || 'OTROS').toUpperCase();

        if (zonaFiltro.includes('BUENAVENTURA')) {
          if (terminal.includes('REGIONAL')) terminal = 'SPRBUN';
          else if (terminal.includes('TCBUEN')) terminal = 'TCBUEN';
          else if (terminal.includes('AGUADULCE')) terminal = 'AGUADULCE';
          else if (terminal.includes('COMPAS')) terminal = 'COMPAS';
          else terminal = 'OTROS';
        } else {
          terminal = terminal
            .replace('SOCIEDAD PORTUARIA', 'SP')
            .replace('REGIONAL DE', 'REG')
            .replace('TERMINAL DE CONTENEDORES DE', 'CON')
            .replace('TERMINAL', 'TERM')
            .trim();
          if (terminal.length > 14) terminal = terminal.substring(0, 14) + '.';
        }

        const totalFila =
          (parseFloat(row.exportacion) || 0) +
          (parseFloat(row.importaci_n || row.importacion) || 0) +
          (parseFloat(row.cabotaje) || 0) +
          (parseFloat(row.transbordo) || 0) +
          (parseFloat(row.fluvial) || 0);
        toneladasPorTerminal[terminal] = (toneladasPorTerminal[terminal] || 0) + totalFila;
        granTotal += totalFila;
      });

      if (granTotal === 0) throw new Error('Datos en ceros desde la API');

      const ordenadas = Object.entries(toneladasPorTerminal)
        .sort((a, b) => b[1] - a[1])
        .map(([nombre, ton]) => ({
          nombre,
          porcentaje: granTotal > 0 ? parseFloat(((ton / granTotal) * 100).toFixed(1)) : 0
        }));

      return {
        labels: ordenadas.map((t) => t.nombre),
        valores: ordenadas.map((t) => t.porcentaje)
      };
    } catch (e) {
      console.warn(`⚠️ API Participación falló para ${ciudadKey}. Usando contingencia adaptativa...`);
      const key = (ciudadKey || '').toUpperCase();

      if (key.includes('CARTAGENA')) {
        return {
        esRespaldo: true,
          labels: ['SP CONTECAR', 'SP REG CARTAGENA', 'COMPAS', 'OTROS'],
          valores: [45.0, 38.0, 11.0, 6.0]
        };
      } else if (key.includes('BARRANQUILLA')) {
        return {
        esRespaldo: true,
          labels: ['SP REG BARRANQUILLA', 'PUERTO PIMSA', 'BITCO', 'PALERMO', 'OTROS'],
          valores: [42.5, 22.0, 18.5, 12.0, 5.0]
        };
      } else if (key.includes('SANTA MARTA')) {
        return {
        esRespaldo: true,
          labels: ['SP REG SANTA MARTA', 'SMI', 'CARBOSAN', 'OTROS'],
          valores: [55.0, 30.0, 10.0, 5.0]
        };
      }
      return {
        esRespaldo: true,
        labels: ['SPRBUN', 'TCBUEN', 'AGUADULCE', 'COMPAS', 'OTROS'],
        valores: [38.5, 25.2, 20.1, 10.5, 5.7]
      };
    }
  }

  async _obtenerTipoOperacion(ciudadKey) {
    const zonaFiltro = await this._zonaSupertransporte(ciudadKey);
    try {
      const respuesta = { data: await Supertransporte.traficoPorZona(zonaFiltro, 4000) };
      let datos = respuesta.data;
      if (!datos || datos.length === 0) throw new Error('Sin datos de operaciones');

      const anioReportado =
        Math.max(...datos.map((d) => parseInt(d.a_o_vigencia || d.vigencia || 0)).filter((a) => a > 0)) ||
        new Date().getFullYear();
      datos = datos.filter((d) => parseInt(d.a_o_vigencia || d.vigencia) === anioReportado);

      let expo = 0;
      let impo = 0;
      let trans = 0;
      let cabo = 0;
      datos.forEach((row) => {
        expo += parseFloat(row.exportacion) || 0;
        impo += parseFloat(row.importaci_n || row.importacion) || 0;
        trans += parseFloat(row.transbordo) || 0;
        cabo += parseFloat(row.cabotaje) || 0;
      });

      const total = expo + impo + trans + cabo;
      if (total === 0) throw new Error('Datos en ceros');

      const getP = (v) => parseFloat(((v / total) * 100).toFixed(1));
      return {
        labels: ['Importación', 'Exportación', 'Transbordo', 'Cabotaje'],
        valores: [getP(impo), getP(expo), getP(trans), getP(cabo)]
      };
    } catch (e) {
      console.warn(`⚠️ API Tipo Operación falló para ${ciudadKey}. Usando contingencia adaptativa...`);
      const key = (ciudadKey || '').toUpperCase();
      let valores;

      if (key.includes('CARTAGENA')) {
        valores = [22.5, 28.1, 46.2, 3.2];
      } else if (key.includes('BARRANQUILLA')) {
        valores = [65.5, 25.2, 5.1, 4.2];
      } else {
        valores = [48.2, 32.5, 12.1, 7.2];
      }
      return {
        esRespaldo: true,
        labels: ['Importación', 'Exportación', 'Transbordo', 'Cabotaje'],
        valores
      };
    }
  }

  async _obtenerMezclaCarga(ciudadKey) {
    const anioActual = new Date().getFullYear();
    const zonaFiltro = await this._zonaSupertransporte(ciudadKey);
    try {
      const respuesta = { data: await Supertransporte.traficoPorZona(zonaFiltro, 4000) };
      let datos = respuesta.data;
      if (!datos || datos.length === 0) throw new Error('Sin datos de mezcla');

      const anioReportado =
        Math.max(...datos.map((d) => parseInt(d.a_o_vigencia || d.vigencia || 0)).filter((a) => a > 0)) ||
        anioActual;
      datos = datos.filter((d) => parseInt(d.a_o_vigencia || d.vigencia) === anioReportado);

      let cont = 0;
      let solido = 0;
      let general = 0;
      let liquido = 0;
      let carbon = 0;
      datos.forEach((row) => {
        cont += parseFloat(row.contenedor || row.contenedores) || 0;
        solido += parseFloat(row.granel_solido) || 0;
        general += parseFloat(row.carga_general) || 0;
        liquido += parseFloat(row.granel_liquido) || 0;
        carbon += parseFloat(row._carbon || row.carbon) || 0;
      });

      const aMt = (v) => parseFloat((v / 1000000).toFixed(2));
      const vCont = aMt(cont);
      const vSol = aMt(solido);
      const vGen = aMt(general);
      const vLiq = aMt(liquido);
      const vCar = aMt(carbon);
      const total = vCont + vSol + vGen + vLiq + vCar;

      if (total === 0) throw new Error('Datos en ceros');

      const pct = Math.round((vCont / total) * 100);
      const lista = [
        { label: 'Contenedores', valor: vCont },
        { label: 'Granel sólido', valor: vSol },
        { label: 'General/vehíc.', valor: vGen },
        { label: 'Granel líquido', valor: vLiq },
        { label: 'Carbón', valor: vCar }
      ].sort((a, b) => b.valor - a.valor);

      return {
        labels: lista.map((i) => i.label),
        valores: lista.map((i) => i.valor),
        subtitulo: `Contenedores domina ${pct}% · ${anioReportado}`
      };
    } catch (e) {
      console.warn(`⚠️ API Mezcla Carga falló para ${ciudadKey}. Usando contingencia adaptativa...`);
      const key = (ciudadKey || '').toUpperCase();
      const anio = new Date().getFullYear();
      const labels = ['Contenedores', 'Granel sólido', 'General/vehíc.', 'Granel líquido', 'Carbón'];
      let valores;
      let sub;

      if (key.includes('BARRANQUILLA')) {
        valores = [4.5, 3.8, 2.9, 1.5, 0.5];
        sub = `Granel Sólido domina 28% · ${anio}`;
      } else if (key.includes('CARTAGENA')) {
        valores = [22.5, 1.2, 0.5, 3.5, 0.1];
        sub = `Contenedores domina 81% · ${anio}`;
      } else {
        valores = [13.8, 6.1, 1.9, 0.8, 0.6];
        sub = `Contenedores domina 60% · ${anio}`;
      }
      return { esRespaldo: true, labels, valores, subtitulo: sub };
    }
  }

  async _obtenerMatrizCarga(ciudadKey) {
    const zonaFiltro = await this._zonaSupertransporte(ciudadKey);
    const anioActual = new Date().getFullYear();
    try {
      const res = { data: await Supertransporte.traficoPorZona(zonaFiltro, 4000) };
      let datos = res.data;
      if (!datos || datos.length === 0) throw new Error('Sin datos');

      const anioReportado =
        Math.max(...datos.map((d) => parseInt(d.a_o_vigencia || d.vigencia || 0)).filter((a) => a > 0)) ||
        anioActual;
      datos = datos.filter((d) => parseInt(d.a_o_vigencia || d.vigencia) === anioReportado);

      const matriz = {};
      let granTotal = 0;

      datos.forEach((row) => {
        let terminal = (row.sociedad_portuaria || 'OTROS').toUpperCase();

        if (zonaFiltro.includes('BUENAVENTURA')) {
          if (terminal.includes('REGIONAL')) terminal = 'SPRBUN';
          else if (terminal.includes('TCBUEN')) terminal = 'TCBUEN';
          else if (terminal.includes('AGUADULCE')) terminal = 'Puerto Aguadulce (SPIA)';
          else if (terminal.includes('COMPAS')) terminal = 'COMPAS Cascajal';
          else terminal = 'Grupo Portuario (M13)';
        } else {
          terminal = terminal.replace('SOCIEDAD PORTUARIA', 'SP').substring(0, 18);
        }

        if (!matriz[terminal]) {
          matriz[terminal] = {
            terminal,
            cont: 0,
            solido: 0,
            general: 0,
            liquido: 0,
            carbon: 0,
            total: 0
          };
        }

        matriz[terminal].cont += parseFloat(row.contenedor || row.contenedores) || 0;
        matriz[terminal].solido += parseFloat(row.granel_solido) || 0;
        matriz[terminal].general += parseFloat(row.carga_general) || 0;
        matriz[terminal].liquido += parseFloat(row.granel_liquido) || 0;
        matriz[terminal].carbon += parseFloat(row._carbon || row.carbon) || 0;

        granTotal +=
          matriz[terminal].cont +
          matriz[terminal].solido +
          matriz[terminal].general +
          matriz[terminal].liquido +
          matriz[terminal].carbon;
      });

      if (granTotal === 0) throw new Error('Datos en ceros');

      const filas = Object.values(matriz)
        .map((f) => {
          f.total = f.cont + f.solido + f.general + f.liquido + f.carbon;
          return f;
        })
        .filter((f) => f.total > 0)
        .sort((a, b) => b.total - a.total);

      return { anio: anioReportado, operadores: filas.length, filas };
    } catch (e) {
      console.warn(`⚠️ API Matriz falló para ${ciudadKey}. Usando contingencia adaptativa...`);
      const key = (ciudadKey || '').toUpperCase();
      const anio = new Date().getFullYear();

      if (key.includes('BARRANQUILLA')) {
        return {
        esRespaldo: true,
          anio,
          operadores: 4,
          filas: [
            { terminal: 'SP REG BARRANQUILLA', cont: 120500, solido: 2500400, general: 800200, liquido: 300100, carbon: 0, total: 3721200 },
            { terminal: 'PALERMO', cont: 0, solido: 600000, general: 300000, liquido: 500000, carbon: 0, total: 1400000 },
            { terminal: 'PUERTO PIMSA', cont: 0, solido: 950000, general: 420000, liquido: 0, carbon: 0, total: 1370000 },
            { terminal: 'BITCO', cont: 85000, solido: 0, general: 150000, liquido: 0, carbon: 0, total: 235000 }
          ]
        };
      } else if (key.includes('CARTAGENA')) {
        return {
        esRespaldo: true,
          anio,
          operadores: 3,
          filas: [
            { terminal: 'SP CONTECAR', cont: 2500000, solido: 0, general: 100000, liquido: 0, carbon: 0, total: 2600000 },
            { terminal: 'SP REG CARTAGENA', cont: 1800000, solido: 200000, general: 50000, liquido: 0, carbon: 0, total: 2050000 },
            { terminal: 'COMPAS CARTAGENA', cont: 0, solido: 800000, general: 20000, liquido: 100000, carbon: 0, total: 920000 }
          ]
        };
      } else {
        return {
        esRespaldo: true,
          anio,
          operadores: 5,
          filas: [
            { terminal: 'SPRBUN', cont: 5379357, solido: 4045105, general: 1518866, liquido: 830059, carbon: 0, total: 11773387 },
            { terminal: 'Puerto Aguadulce (SPIA)', cont: 5149683, solido: 760216, general: 347621, liquido: 0, carbon: 796111, total: 7053631 },
            { terminal: 'TCBUEN', cont: 3212394, solido: 0, general: 13, liquido: 0, carbon: 0, total: 3212407 },
            { terminal: 'COMPAS Cascajal', cont: 0, solido: 1070395, general: 0, liquido: 0, carbon: 0, total: 1070395 },
            { terminal: 'Grupo Portuario (M13)', cont: 0, solido: 3630, general: 0, liquido: 0, carbon: 0, total: 3630 }
          ]
        };
      }
    }
  }

  async _obtenerHistoricoAnual(ciudadKey) {
    const zonaFiltro = await this._zonaSupertransporte(ciudadKey);
    try {
      const res = { data: await Supertransporte.traficoPorZona(zonaFiltro, 10000) };
      if (!res.data || res.data.length === 0) throw new Error('Sin datos');

      const agrupadoPorAnio = {};
      let granTotal = 0;

      res.data.forEach((row) => {
        const anio = parseInt(row.a_o_vigencia || row.vigencia || 0);
        if (anio < 2018) return;

        const totalRow =
          (parseFloat(row.exportacion) || 0) +
          (parseFloat(row.importaci_n || row.importacion) || 0) +
          (parseFloat(row.cabotaje) || 0) +
          (parseFloat(row.transbordo) || 0) +
          (parseFloat(row.fluvial) || 0);

        agrupadoPorAnio[anio] = (agrupadoPorAnio[anio] || 0) + totalRow;
        granTotal += totalRow;
      });

      if (granTotal === 0) throw new Error('Datos en ceros');

      const aniosOrdenados = Object.keys(agrupadoPorAnio).sort();
      const labels = aniosOrdenados;
      const valores = aniosOrdenados.map((a) =>
        parseFloat((agrupadoPorAnio[a] / 1000000).toFixed(2))
      );

      return { rango: `${labels[0]}-${labels[labels.length - 1]}`, labels, valores };
    } catch (e) {
      console.warn(`⚠️ API Histórico falló para ${ciudadKey}. Usando contingencia adaptativa...`);
      const key = (ciudadKey || '').toUpperCase();
      const labels = ['2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'];
      let valores;

      if (key.includes('BARRANQUILLA')) {
        valores = [11.2, 10.5, 9.8, 11.0, 12.5, 12.8, 13.5, 14.2];
      } else if (key.includes('CARTAGENA')) {
        valores = [28.5, 29.0, 26.5, 29.8, 31.2, 33.0, 34.5, 36.1];
      } else {
        valores = [25.5, 20.8, 17.4, 18.0, 19.8, 19.0, 20.7, 23.1];
      }

      return { esRespaldo: true, rango: '2018-2025', labels, valores };
    }
  }

  async _obtenerImplicacionesOperativas(ciudadKey) {
    const zonaFiltro = await this._zonaSupertransporte(ciudadKey);

    try {
      const respuesta = { data: await Supertransporte.traficoPorZona(zonaFiltro, 5000) };
      let datos = respuesta.data;
      if (!datos || datos.length === 0) throw new Error('Sin datos para insights');

      const anioReportado =
        Math.max(...datos.map((d) => parseInt(d.a_o_vigencia || d.vigencia || 0)).filter((a) => a > 0)) ||
        new Date().getFullYear();
      datos = datos.filter((d) => parseInt(d.a_o_vigencia || d.vigencia) === anioReportado);

      let cont = 0;
      let solido = 0;
      let general = 0;
      let liquido = 0;
      let carbon = 0;
      let expo = 0;
      let impo = 0;
      let trans = 0;
      let cabo = 0;
      const terminales = {};

      datos.forEach((row) => {
        const c = parseFloat(row.contenedor || row.contenedores) || 0;
        const s = parseFloat(row.granel_solido) || 0;
        const g = parseFloat(row.carga_general) || 0;
        const l = parseFloat(row.granel_liquido) || 0;
        const cb = parseFloat(row._carbon || row.carbon) || 0;
        cont += c;
        solido += s;
        general += g;
        liquido += l;
        carbon += cb;

        expo += parseFloat(row.exportacion) || 0;
        impo += parseFloat(row.importaci_n || row.importacion) || 0;
        trans += parseFloat(row.transbordo) || 0;
        cabo += parseFloat(row.cabotaje) || 0;

        const term = (row.sociedad_portuaria || 'OTROS')
          .toUpperCase()
          .replace('SOCIEDAD PORTUARIA', 'SP')
          .substring(0, 15);
        terminales[term] = (terminales[term] || 0) + (c + s + g + l + cb);
      });

      const totalCarga = cont + solido + general + liquido + carbon;
      const totalOps = expo + impo + trans + cabo;
      if (totalCarga === 0) throw new Error('Datos en ceros');

      const topTerm = Object.entries(terminales).sort((a, b) => b[1] - a[1])[0] || ['SPRBUN', 0];
      const aMt = (v) => (v / 1000000).toFixed(1);

      const pctCont = Math.round((cont / totalCarga) * 100);
      const pctSol = Math.round((solido / totalCarga) * 100);
      const pctImpo = totalOps > 0 ? Math.round((impo / totalOps) * 100) : 0;
      const pctExpo = totalOps > 0 ? Math.round((expo / totalOps) * 100) : 0;
      const pctTrans = totalOps > 0 ? Math.round((trans / totalOps) * 100) : 0;

      let mainVocacion = pctImpo > pctExpo ? `IMPORTADOR (${pctImpo}%)` : `EXPORTADOR (${pctExpo}%)`;
      if (pctTrans > Math.max(pctImpo, pctExpo)) mainVocacion = `HUB DE TRANSBORDO (${pctTrans}%)`;

      return {
        insights: [
          {
            color: '#3b82f6',
            titulo: `Operación de Contenedores (${pctCont}%)`,
            descripcion: `Representa un volumen de ${aMt(cont)} Mt movilizadas. El líder operativo en la zona es ${topTerm[0]} con ${aMt(topTerm[1])} Mt en total. Vigilar congestión de vacíos y disponibilidad de grúas STS.`
          },
          {
            color: '#10b981',
            titulo: `Granel Sólido (${pctSol}%)`,
            descripcion: `Volumen actual de ${aMt(solido)} Mt este año. La torre debe priorizar la inspección de calado del canal de acceso y la disponibilidad de silos o bodegas para descarga directa.`
          },
          {
            color: '#f59e0b',
            titulo: `Carga General y Vehículos (${Math.round((general / totalCarga) * 100)}%)`,
            descripcion: `Se movieron ${aMt(general)} Mt de carga suelta. Requiere disponibilidad constante de equipos pesados (reach stackers, grúas multipropósito) y coordinación en patios Ro-Ro.`
          },
          {
            color: '#06b6d4',
            titulo: `Flujo Operativo: Perfil ${mainVocacion}`,
            descripcion: `La logística debe alinearse a este flujo dominante. La mezcla real es: Transbordo ${pctTrans}%, Importación ${pctImpo}%, Exportación ${pctExpo}%, Cabotaje ${totalOps > 0 ? Math.round((cabo / totalOps) * 100) : 0}%.`
          }
        ]
      };
    } catch (e) {
      console.warn('⚠️ API Insights falló. Usando contingencia estática...');
      return {
        esRespaldo: true,
        insights: [
          {
            color: '#3b82f6',
            titulo: 'Operación de contenedores - prioridad máxima',
            descripcion:
              'La saturación de patios reefer y depots de vacíos es el primer indicador a vigilar en las terminales principales.'
          },
          {
            color: '#10b981',
            titulo: 'Granel sólido - segunda prioridad',
            descripcion:
              'Monitorear la rotación en bodegas y coordinar despachos directos para evitar cuellos de botella en muelles.'
          },
          {
            color: '#f59e0b',
            titulo: 'Carga general e industrial',
            descripcion:
              'Vigilar disponibilidad de equipos de izaje y consolidación de proyectos especiales en zona extraportuaria.'
          },
          {
            color: '#38bdf8',
            titulo: 'Flujo operativo predominante',
            descripcion:
              'Asegurar cruces de Virtual Gate fluidos y priorizar el retiro rápido de mercancía de importación.'
          }
        ]
      };
    }
  }

  async _obtenerWidgetProductividad(puertoKey) {
    try {
      const dataCruda = await MaritimoRepository.getProductividadIntradiaria(puertoKey).catch(() => []);

      if (!dataCruda || dataCruda.length === 0) {
        return { titulo: 'PRODUCTIVIDAD (MOVS/H)', labels: [], datasets: [] };
      }

      const horasSet = new Set(dataCruda.map((d) => d.hora_etiqueta));
      const labels = Array.from(horasSet).sort();
      const terminalesSet = new Set(dataCruda.map((d) => d.terminal));
      const terminales = Array.from(terminalesSet).sort();

      const datasets = terminales.map((nombreTerminal) => {
        const datosTerminal = dataCruda.filter((d) => d.terminal === nombreTerminal);
        const valoresOrdenados = labels.map((hora) => {
          const registro = datosTerminal.find((d) => d.hora_etiqueta === hora);
          return registro ? registro.movimientos_hora : 0;
        });

        const colorBase = this._generarColorPorNombre(nombreTerminal);
        const colorFondo = colorBase.replace(')', ', 0.15)').replace('hsl', 'hsla');

        return {
          label: nombreTerminal,
          data: valoresOrdenados,
          borderColor: colorBase,
          backgroundColor: colorFondo,
          fill: true,
          tension: 0.4,
          borderWidth: 2,
          pointBackgroundColor: '#1e293b',
          pointBorderColor: colorBase,
          pointBorderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6
        };
      });

      return {
        titulo: 'PRODUCTIVIDAD (MOVS/H)',
        labels,
        datasets
      };
    } catch (error) {
      console.error('[Service] ❌ Error empaquetando gráfica de productividad:', error);
      return { titulo: 'PRODUCTIVIDAD (MOVS/H)', labels: [], datasets: [] };
    }
  }

  async _obtenerGeoJsonClimaNacional() {
    try {
      const puertos = await MaritimoRepository.getPuertosActivos().catch(() => []);
      if (!puertos || puertos.length === 0) return { type: 'FeatureCollection', features: [] };

      const promesasClima = puertos.map((p) =>
        ExternalIntegrationService.getWeatherData(p.lat, p.lon)
      );
      const resultados = await Promise.all(promesasClima);

      const features = resultados
        .map((weather, index) => {
          if (!weather) return null;

          const puerto = puertos[index];
          const hasBbox = puerto.bbox_lat_sur !== null && puerto.bbox_lon_oeste !== null;
          const bbox = hasBbox
            ? [puerto.bbox_lon_oeste, puerto.bbox_lat_sur, puerto.bbox_lon_este, puerto.bbox_lat_norte]
            : null;

          return {
            type: 'Feature',
            geometry: {
              type: 'Point',
              coordinates: [puerto.lon, puerto.lat]
            },
            properties: {
              id: puerto.id_puerto,
              zona: puerto.nombre,
              temp: weather.main?.temp || 0,
              viento: weather.wind?.speed || 0,
              presion: weather.main?.pressure || 0,
              descripcion: weather.weather?.[0]?.description || 'Sin datos',
              bbox
            }
          };
        })
        .filter((f) => f !== null);

      return {
        type: 'FeatureCollection',
        features
      };
    } catch (error) {
      console.error('🔥 Error generando GeoJSON:', error);
      return { type: 'FeatureCollection', features: [] };
    }
  }

  /** Supertransporte no respondió (2026-10-23): se dice así, sin cifras fijas ni series aleatorias. */
  _obtenerMockAnalisisTrafico() {
    return {
      esRespaldo: true,
      titulo: 'ANÁLISIS DE TRÁFICO PORTUARIO',
      subtitulo: 'Supertransporte (datos.gov.co) no respondió · sin datos',
      kpisTop: {
        toneladas: { valor: '—', detalle: 'Sin respuesta de la fuente' },
        variacion: { valor: '—', detalle: 'Sin respuesta de la fuente', claseTendencia: 'text-muted' },
        participacion: { valor: '—', detalle: 'Sin respuesta de la fuente' },
        flujo: { valor: '—', detalle: 'Sin respuesta de la fuente', claseTendencia: 'text-muted' }
      },
      chartEvolucion: { labels: [], datasets: [] }
    };
  }


  _procesarArribosSemanal(motonaves) {
    const labels = [];
    const conteo = {};
    const hoy = new Date();

    for (let i = 0; i < 7; i++) {
      const d = new Date();
      d.setDate(hoy.getDate() + i);
      const dia = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`;
      labels.push(dia);
      conteo[dia] = 0;
    }

    (Array.isArray(motonaves) ? motonaves : []).forEach((m) => {
      const dia = String(m?.eta || '').split(' ')[0];
      if (Object.prototype.hasOwnProperty.call(conteo, dia)) {
        conteo[dia] += 1;
      }
    });

    return {
      labels,
      data: Object.values(conteo)
    };
  }

  _calcularTendencia(valorActual, valorAnterior, sufijo = 'vs sem.') {
    if (valorAnterior === 0) {
      return { texto: '▲ N/A (nuevo)', clase: 'text-success' };
    }

    const diferencia = valorActual - valorAnterior;
    const porcentaje = ((diferencia / valorAnterior) * 100).toFixed(1);

    if (diferencia > 0) {
      return { texto: `▲ +${porcentaje}% ${sufijo}`, clase: 'text-success' };
    } else if (diferencia < 0) {
      return { texto: `▼ ${porcentaje}% ${sufijo}`, clase: 'text-danger' };
    }
    return { texto: `= 0% ${sufijo}`, clase: 'text-muted' };
  }

  _formatearNumeroCompacto(valor) {
    if (valor === null || valor === undefined || isNaN(valor)) return '0';
    const num = Number(valor);
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toLocaleString('es-CO');
  }

  _generarColorPorNombre(nombre) {
    let hash = 0;
    const texto = String(nombre || 'TERMINAL');
    for (let i = 0; i < texto.length; i++) {
      hash = texto.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hue = Math.abs(hash % 360);
    return `hsl(${hue}, 70%, 60%)`;
  }
}

module.exports = new MaritimoService();
module.exports.verificarConAis = verificarConAis;
module.exports.mismoBarco = mismoBarco;