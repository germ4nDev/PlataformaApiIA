/*
    Author: German Valencia
    Pattern: PORTTOS Service - Mapa General (Gemelo Digital)
    Descripción: Orquestador limpio de capas espaciales (Vías, Infraestructura, Terrestre, Clima, Incidentes).
*/
const fs = require('fs');
const path = require('path');
const ExternalIntegrationService = require('../../adapters/fuentes-externas.adapter');
const MaritimoRepository = require('../../repositories/torre-control/mapa-general.repository');
const { cajaPuerto, MARGEN } = require('../../helpers/caja-puerto.helper');
const { estadoSenalAis } = require('../../utils/senal-ais');

class MapaGeneralService {
  constructor(repository) {
    this.repository = repository;
  }

  // ==========================================
  // 1. CAPA INFRAESTRUCTURA
  // ==========================================
  async getCapaInfraestructura() {
    try {
      const data = await this.repository.getInfraestructuraJerarquica();
      if (!data || data.length === 0) {
        return { success: true, data: [] };
      }
      return { success: true, data: data };
    } catch (error) {
      console.error('❌ ERROR REAL DE BASE DE DATOS [Infraestructura]:', error);
      throw error;
    }
  }

  // ==========================================
  // 2. CAPA TERRESTRE (GPS FLOTA)
  // ==========================================
  async getCapaTerrestre() {
    try {
      const flota = await this.repository.getFlotaTerrestreActiva();
      const geoJson = {
        type: 'FeatureCollection',
        features: flota.map(v => ({
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: [parseFloat(v.longitud), parseFloat(v.latitud)]
          },
          properties: {
            capa: 'TERRESTRE',
            placa: v.placa,
            estado: v.estado,
            conductor: v.conductor,
            velocidad: v.velocidad
          }
        }))
      };
      return { success: true, data: geoJson };
    } catch (error) {
      console.error("🔥 [Terrestre] Error en orquestación:", error);
      throw new Error('Fallo al generar la capa terrestre.');
    }
  }

  // ==========================================
  // 3. CAPA CLIMA (IDEAM / OPENWEATHER)
  // ==========================================
  async getCapaClima() {
    try {
      const puertos = await this.repository.getInfraestructuraActiva();
      const promesas = puertos.map(p => ExternalIntegrationService.getWeatherData(p.lat, p.lon));
      const resultados = await Promise.all(promesas);

      // Corregido 2026-10-17: antes se filtraban los puertos sin clima ANTES de emparejar por índice,
      // así que si un puerto fallaba los siguientes quedaban con el nombre y la ubicación del puerto equivocado.
      const geoJson = {
        type: 'FeatureCollection',
        features: puertos
          .map((p, i) => ({ p, w: resultados[i] }))
          .filter(({ w }) => w)
          .map(({ p, w }) => ({
            type: 'Feature',
            geometry: { type: 'Point', coordinates: [p.lon, p.lat] },
            properties: {
              zona: p.nombre,
              temp: w.main?.temp,
              descripcion: w.weather?.[0]?.description
            }
          }))
      };
      return { success: true, data: geoJson };
    } catch (error) {
      console.error("🔥 [Clima] Error en orquestación:", error);
      throw new Error('Fallo al generar la capa de clima.');
    }
  }

  // ==========================================
  // 4. CAPA VIAS + INCIDENTES (CRUCE INTELIGENTE)
  // ==========================================
  async getCapaVialEnriquecida() {
    try {
      // 1. Cargar Vías (Local) e Incidentes (DB) en paralelo
      const [vias, incidentes] = await Promise.all([
        this._leerGeoJsonVias(),
        this.repository.getIncidentesVialesActivos()
      ]);

      // 2. Cruce inteligente
      const viasEnriquecidas = this._cruzarViasConIncidentes(vias, incidentes);

      return { success: true, data: viasEnriquecidas };
    } catch (error) {
      console.error("🔥 [Vías/Incidentes] Error en orquestación:", error);
      throw new Error('Fallo al consolidar la capa vial.');
    }
  }

  _leerGeoJsonVias() {
    try {
      // Ajusta esta ruta a la carpeta donde alojarás tus archivos GeoJSON oficiales
      const ruta = path.join(__dirname, '../../../data/Red_Vial_20260626.geojson');
      const data = fs.readFileSync(ruta, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      console.error('❌ Error leyendo GeoJSON de vías:', error);
      return { type: 'FeatureCollection', features: [] };
    }
  }

  _cruzarViasConIncidentes(vias, incidentes) {
    if (!vias.features) return vias;

    // Indexamos incidentes para búsqueda O(1) basada en el nombre del tramo
    const incidentesMap = incidentes.reduce((acc, inc) => {
      const key = this._normalizarString(inc.tramo_nombre || inc.ID_VIAL);
      acc[key] = inc;
      return acc;
    }, {});

    // Enriquecemos la red vial
    return {
      ...vias,
      features: vias.features.map(f => {
        const nombreVial = this._normalizarString(f.properties.nombre_tramo || f.properties.ID);
        const incidente = incidentesMap[nombreVial];

        return {
          ...f,
          properties: {
            ...f.properties,
            estado: incidente ? 'congestionado' : 'libre',
            incidente_tipo: incidente ? incidente.tipo_evento : null,
            severidad: incidente ? incidente.nivel_severidad : 0
          }
        };
      })
    };
  }

  // ==========================================
  // 5. CAPA NAVES
  // ==========================================
  /**
   * @param {string} [puerto] filtro opcional del tablero (agregado 2026-10-18)
   * `senal` (2026-10-29, OT-007): con puerto, si la capa sale vacía dice desde cuándo no reporta el AIS en su caja.
   */
  async getCapaNaves(puerto) {
    try {
      const caja = await cajaPuerto(puerto, MARGEN.MARITIMO);
      const naves = await this.repository.getUltimasPosicionesNaves({ caja });
      // OT-009: las naves simuladas (MMSI 'SIM…', nombre 'SIM · …') se dibujan, pero no cuentan como señal AIS en vivo
      const esSimulada = (f) => String(f?.properties?.mmsi || '').startsWith('SIM');
      const cuantas = (naves?.features || []).filter((f) => !esSimulada(f)).length;
      const simuladas = (naves?.features || []).length - cuantas;
      if (!caja) return { success: true, data: naves, senal: null };
      let ultima = null;
      if (cuantas === 0) {
        try { ultima = await this.repository.getUltimaSenalAis({ caja }); } catch (e) { console.warn('⚠️ [Naves] Sin fecha de última señal AIS:', e.message); }
      }
      return { success: true, data: naves, senal: { ...estadoSenalAis({ naves: cuantas, ultima, ahora: new Date() }), simuladas } };
    } catch (error) {
      console.error('❌ [Naves] Error en Capa Naves:', error);
      throw new Error('Fallo al generar la capa de naves.');
    }
  }

  // ==========================================
  // SIMULACIÓN
  // ==========================================
  async simularMovimientoFlota() {
    try {
      return await this.repository.actualizarPosicionesSimuladas();
    } catch (error) {
      console.error('❌ Error al ejecutar simularMovimientoFlota:', error);
      throw error;
    }
  }

  // ==========================================
  // SINCRONIZACION OPTIMIZADA
  // ==========================================
  async ejecutarSincronizacionCompleta() {
    try {
      // 1. Eventos viales: un solo camino de escritura, con su ciclo de vida (2026-10-26). Antes este método
      //    escribía por su cuenta con otro mapeo y sin despejar nada. Se carga aquí para no crear un ciclo.
      await require('./sincronizacion.service').sincronizarEventosViales();

      // 2. Sincronizar Alertas Climáticas
      const alertas = await ExternalIntegrationService.getAlertasClimaticasOficiales();
      const promesasAlertas = alertas.map(item =>
        this.repository.upsertAlertaClimatica(this._mapearAlertaClimatica(item))
      );
      await Promise.all(promesasAlertas);
    } catch (error) {
      console.error("❌ Error grave durante la sincronización:", error);
    }
  }

  async diagnosticarEsquemaFuente(fuente = 'vial') {
    try {
      let datos = [];
      if (fuente === 'vial') {
        datos = await ExternalIntegrationService.getEventosVialesOficiales();
      } else if (fuente === 'clima') {
        datos = await ExternalIntegrationService.getAlertasClimaticasOficiales();
      }

      if (datos && datos.length > 0) {
        // console.dir(datos[0], { depth: null });   // [ruido de consola: comentado 2026-10-26]
      } else {
        console.warn("⚠️ La API devolvió un array vacío o falló.");
      }
    } catch (error) {
      console.error("❌ Error en diagnóstico:", error);
    }
  }

  async obtenerDashboardMaritimo() {
    // Aquí podrías agregar lógica de negocio adicional (ej. transformar WKT a GeoJSON)
    // Por ahora, retornamos la data enriquecida con el estado espacial
    const data = await this.repository.getBuquesConEstadoOperativo();

    return data.map(item => ({
      ...item,
      timestamp: new Date().toISOString(), // Añadir meta-data de consulta
      fuente: 'AIS-Spatial-Correlation'
    }));
  }

  // Mapeo específico para dbo.TCL_EventosViales
  _mapearEventoVial(item) {
    return {
      codigoEvento: item.uuid || item.id_unico,
      corredorVial: item.nombre_via || 'N/A',
      sector: item.ubicacion || 'N/A',
      tipoEvento: item.tipo_evento || 'GENERAL',
      descripcion: item.descripcion_corta || '',
      nivelSeveridad: parseInt(item.impacto) || 1,
      estadoEvento: 'ACTIVO',
      fechalnicio: item.fecha_reporte || new Date(),
      codigousuariocreacion: 'SYSTEM_CRON',
      fechacreacion: new Date()
    };
  }

  // Mapeo específico para dbo.TCL_AlertasClimaticas
  _mapearAlertaClimatica(item) {
    return {
      codigoAlerta: item.id_alerta,
      region: item.zona_afectada || 'N/A',
      corredorVial: item.corredor || 'N/A',
      sector: item.sector || 'N/A',
      tipoAlerta: item.tipo || 'CLIMA',
      descripcion: item.detalle || '',
      intensidadPrecipitacion: parseFloat(item.precipitacion) || 0,
      velocidadViento: parseFloat(item.viento) || 0,
      visibilidadEstimada: parseInt(item.visibilidad) || 10,
      nivelSeveridad: parseInt(item.nivel) || 1,
      estadoAlerta: 'ACTIVO',
      fechalnicio: item.fecha || new Date(),
      codigousuariocreacion: 'SYSTEM_CRON',
      fechacreacion: new Date()
    };
  }

  // ==========================================
  // UTILS
  // ==========================================
  _normalizarString(str) {
    if (!str) return 'unknown';
    return str.toString().toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // Limpieza de tildes
      .replace(/[^a-z0-9]/g, ''); // Limpieza de caracteres especiales
  }

  _emptyGeoJson() {
    return { type: 'FeatureCollection', features: [] };
  }
}

/** Servicio con su repositorio por defecto (los controladores usan esto; las pruebas inyectan el suyo). */
let porDefecto = null;
MapaGeneralService.porDefecto = () => {
  if (!porDefecto) porDefecto = new MapaGeneralService(require('../../repositories/torre-control/mapa-general.repository').porDefecto());
  return porDefecto;
};

module.exports = MapaGeneralService;